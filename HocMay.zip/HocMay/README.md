# YOLOv8n + BoTNet + WIoU-like + LSKA + ODConv for Small Traffic Sign Detection

This project is a practical, research-oriented YOLOv8 customization for small traffic sign detection under adverse conditions. It starts from Ultralytics YOLOv8n and adds:

- `BoTNet` after `SPPF` in the backbone
- `C2f_LSKA` blocks in the neck/head
- `ODConv` in selected PAN downsampling layers
- `WIoU-like` bbox regression loss patch
- `weather augmentation` on a selected portion of the train split
- `small-sign copy-paste augmentation`

## What is exact and what is approximation

This repo is intentionally practical rather than claiming exact paper reproduction.

- `YOLOv8n` base structure: close to Ultralytics implementation
- `BoTNet`: paper-inspired practical module for low-resolution backbone features
- `LSKA` / `C2f_LSKA`: practical approximation adapted to YOLO feature maps
- `ODConv`: lightweight practical dynamic convolution, not a full reproduction of every ODConv design choice from the paper
- `WIoU`: implemented as `WIoU-like approximation`, not full WIoU-v3 unless you replace the loss with your own exact version

Recommended wording for reports:

- Use `paper-inspired`
- Use `practical approximation`
- Do not claim `exact reproduction` unless you replace these modules with verified paper-faithful implementations

## Compatibility

- Recommended version: `ultralytics==8.2.103`
- The parser patch instructions below are written for the 8.2.x family
- If your installed Ultralytics parser differs, adapt the `parse_model()` patch as explained in section `Ultralytics patch guide`

## Project structure

```text
project/
├── datasets/
│   └── traffic_sign/
│       ├── images/
│       │   ├── train/
│       │   ├── val/
│       │   └── test/
│       ├── labels/
│       │   ├── train/
│       │   ├── val/
│       │   └── test/
│       ├── data.yaml
│       └── data_aug.yaml
├── ultralytics/
│   └── nn/
│       └── modules/
│           ├── lska.py
│           ├── odconv.py
│           └── botnet.py
├── augment_weather_smallsign.py
├── train_custom.py
├── yolov8n_bot_wiou_lska_odconv.yaml
├── requirements.txt
└── README.md
```

## Environment setup

### Local / VS Code

```bash
python -m venv .venv
.venv\Scripts\activate
pip install --upgrade pip
pip install -r requirements.txt
```

### Colab

```bash
pip install -r requirements.txt
```

## Dataset format

Place your YOLO-format dataset at:

```text
datasets/traffic_sign/
├── images/train/*.jpg
├── images/val/*.jpg
├── images/test/*.jpg
├── labels/train/*.txt
├── labels/val/*.txt
└── labels/test/*.txt
```

Each label line must follow:

```text
class_id x_center y_center width height
```

All box values are normalized to `[0, 1]`.

## Class count and `nc`

- `data.yaml` and `data_aug.yaml` in this repo are examples for a `43-class` traffic sign dataset
- You must update `nc` and `names` if your dataset uses a different label set
- In `yolov8n_bot_wiou_lska_odconv.yaml`, `nc` is a placeholder because Ultralytics overrides model `nc` using the dataset yaml during training
- The safest place to define the true class count is the dataset yaml

## Augmentation modes

The augmentation script supports two train-set behaviors:

- `append`: keep original train images and add new augmented `*_aug` samples
- `replace`: replace exactly the selected `weather_ratio` portion of the train set with augmented versions

If you want to stay closer to the interpretation of `30% of train set is augmented`, `replace` is the better experimental setting and is the default in this repo.

## Generate augmented dataset

### Replace mode, closer to the paper-style interpretation

```bash
python augment_weather_smallsign.py --src datasets/traffic_sign --dst datasets/traffic_sign_aug --weather-ratio 0.30 --small-sign-ratio 0.50 --augment-mode replace --overwrite
```

### Append mode, useful when you want a larger train set

```bash
python augment_weather_smallsign.py --src datasets/traffic_sign --dst datasets/traffic_sign_aug --weather-ratio 0.30 --small-sign-ratio 0.50 --augment-mode append --overwrite
```

The script writes:

- a copied `val` split
- a copied `test` split
- a processed `train` split in either `append` or `replace` mode
- `datasets/traffic_sign_aug/data_aug.yaml`

## Ultralytics patch guide

You must patch the installed Ultralytics package before training.

### Step 1. Locate the installed package

```bash
python -c "import ultralytics, pathlib; print(pathlib.Path(ultralytics.__file__).resolve().parent)"
```

### Step 2. Copy custom modules

Copy these files into the installed package:

- `ultralytics/nn/modules/lska.py`
- `ultralytics/nn/modules/odconv.py`
- `ultralytics/nn/modules/botnet.py`

### Step 3. Update `ultralytics/nn/modules/__init__.py`

Add imports for:

- `BoTNet`
- `LSKA`
- `Bottleneck_LSKA`
- `C2f_LSKA`
- `ODConv`
- `ODConv2d`

### Step 4. Update `ultralytics/nn/tasks.py`

Patch `parse_model()` so it recognizes:

- `BoTNet`
- `C2f_LSKA`
- `ODConv`

Important:

- `ODConv` should be treated like a Conv-like module with `c1 -> c2`
- `C2f_LSKA` should be treated like `C2f`, including repeat handling
- `BoTNet` should preserve channels as configured in the YAML

### Step 5. Update `ultralytics/utils/loss.py`

Replace the CIoU call with a helper clearly named `bbox_iou_wiou_like()`.

Important:

- This repo does not claim full WIoU-v3 reproduction
- The recommended naming in code and report is `WIoU-like approximation`

## Train

### Local

```bash
python train_custom.py --data datasets/traffic_sign_aug/data_aug.yaml --model yolov8n_bot_wiou_lska_odconv.yaml --epochs 150 --imgsz 640 --batch 16 --device 0
```

### CPU fallback

```bash
python train_custom.py --data datasets/traffic_sign_aug/data_aug.yaml --device cpu --batch 4
```

### Colab

```bash
python train_custom.py --data datasets/traffic_sign_aug/data_aug.yaml --model yolov8n_bot_wiou_lska_odconv.yaml --epochs 150 --imgsz 640 --batch 32 --device 0
```

Results are stored in:

```text
runs/custom_traffic_sign/yolov8n_bot_wiou_lska_odconv/
```

Best checkpoint:

```text
runs/custom_traffic_sign/yolov8n_bot_wiou_lska_odconv/weights/best.pt
```

Download on Colab:

```python
from google.colab import files
files.download("runs/custom_traffic_sign/yolov8n_bot_wiou_lska_odconv/weights/best.pt")
```

## Checklist before training

- Confirm `datasets/traffic_sign_aug/data_aug.yaml` exists
- Confirm `path`, `train`, `val`, and `test` in dataset yaml are correct
- Confirm `nc` matches the number of entries in `names`
- Confirm the custom files were copied into the installed `ultralytics/nn/modules/`
- Confirm `ultralytics/nn/modules/__init__.py` imports the custom modules
- Confirm `ultralytics/nn/tasks.py` was patched to parse `BoTNet`, `C2f_LSKA`, and `ODConv`
- Confirm `ultralytics/utils/loss.py` was patched to call `bbox_iou_wiou_like()`
- Confirm your GPU memory can handle the selected `batch` and `imgsz`
- If you hit OOM, reduce `batch` first, then reduce `imgsz`

## Common issues

### Parser cannot find custom modules

- Re-check `__init__.py`
- Re-check `tasks.py`
- Make sure the installed package is the same one used by your Python environment

### Shape mismatch

- Use the provided YAML first
- Do not change BoTNet channels unless you also update parser handling
- Keep Detect input indices as `P3/P4/P5 = [16, 19, 22]` unless you intentionally redesign the neck

### Loss patch confusion

- If your code still calls `bbox_iou(..., CIoU=True)`, then your WIoU-like patch is not active
- Use the name `bbox_iou_wiou_like()` in code so the approximation is explicit

### CUDA OOM

- Reduce `batch`
- Reduce `imgsz`
- Reduce ODConv usage or kernel count if you customize the module further
