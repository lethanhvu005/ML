from __future__ import annotations

import argparse
import json
import random
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import cv2
import numpy as np
import yaml
from tqdm import tqdm


IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


@dataclass
class YoloBox:
    cls_id: int
    xc: float
    yc: float
    w: float
    h: float

    def to_line(self) -> str:
        return f"{self.cls_id} {self.xc:.6f} {self.yc:.6f} {self.w:.6f} {self.h:.6f}"

    def area_norm(self) -> float:
        return self.w * self.h

    def to_xyxy(self, img_w: int, img_h: int) -> tuple[int, int, int, int]:
        x1 = int((self.xc - self.w / 2.0) * img_w)
        y1 = int((self.yc - self.h / 2.0) * img_h)
        x2 = int((self.xc + self.w / 2.0) * img_w)
        y2 = int((self.yc + self.h / 2.0) * img_h)
        return x1, y1, x2, y2


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create weather + small-sign augmented YOLO dataset.")
    parser.add_argument("--src", type=str, default="datasets/traffic_sign", help="Source dataset root.")
    parser.add_argument("--dst", type=str, default="datasets/traffic_sign_aug", help="Output dataset root.")
    parser.add_argument("--weather-ratio", type=float, default=0.30, help="Fraction of train images selected for weather augmentation.")
    parser.add_argument("--small-sign-ratio", type=float, default=0.50, help="Fraction of selected images that also receive small-sign copy-paste augmentation.")
    parser.add_argument("--small-threshold", type=float, default=0.015, help="Normalized bbox area threshold for small signs.")
    parser.add_argument("--max-paste", type=int, default=3, help="Maximum pasted small signs per selected image.")
    parser.add_argument(
        "--augment-mode",
        type=str,
        default="replace",
        choices=["append", "replace"],
        help="append: keep originals and add new *_aug samples; replace: only selected ratio is replaced by augmented samples.",
    )
    parser.add_argument(
        "--sampling-mode",
        type=str,
        default="dynamic",
        choices=["dynamic", "static"],
        help=(
            "dynamic: choose a non-repeating subset across runs using --state-file; "
            "static: use ordinary random sampling for one fixed generated dataset."
        ),
    )
    parser.add_argument(
        "--state-file",
        type=str,
        default="augment_state.json",
        help="JSON file that stores which train images were already selected for dynamic augmentation.",
    )
    parser.add_argument(
        "--reset-state",
        action="store_true",
        help="Delete --state-file before sampling, starting a new dynamic augmentation cycle.",
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")
    parser.add_argument("--overwrite", action="store_true", help="Delete destination directory before writing.")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)


def load_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def save_yaml(data: dict, path: Path) -> None:
    with path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)


def load_labels(label_path: Path) -> list[YoloBox]:
    if not label_path.exists():
        return []
    boxes: list[YoloBox] = []
    for line in label_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) != 5:
            continue
        cls_id, xc, yc, w, h = parts
        boxes.append(YoloBox(int(float(cls_id)), float(xc), float(yc), float(w), float(h)))
    return boxes


def save_labels(label_path: Path, boxes: Iterable[YoloBox]) -> None:
    label_path.write_text("\n".join(box.to_line() for box in boxes), encoding="utf-8")


def ensure_clean_dir(dst: Path, overwrite: bool) -> None:
    if dst.exists() and overwrite:
        shutil.rmtree(dst)
    dst.mkdir(parents=True, exist_ok=True)


def collect_images(images_dir: Path) -> list[Path]:
    return sorted([p for p in images_dir.iterdir() if p.suffix.lower() in IMG_EXTS and p.is_file()])


def _relative_image_id(img_path: Path, dataset_root: Path) -> str:
    """Stable image id for state tracking, independent of absolute machine path."""
    try:
        return img_path.relative_to(dataset_root).as_posix()
    except ValueError:
        return img_path.name


def load_augment_state(state_file: Path) -> dict:
    if not state_file.exists():
        return {"cycle": 1, "used": []}
    try:
        with state_file.open("r", encoding="utf-8") as f:
            state = json.load(f)
    except json.JSONDecodeError:
        state = {"cycle": 1, "used": []}
    if not isinstance(state, dict):
        state = {"cycle": 1, "used": []}
    state.setdefault("cycle", 1)
    state.setdefault("used", [])
    return state


def save_augment_state(state: dict, state_file: Path) -> None:
    state_file.parent.mkdir(parents=True, exist_ok=True)
    with state_file.open("w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def dynamic_sample_without_replacement(
    image_paths: list[Path],
    sample_count: int,
    dataset_root: Path,
    state_file: Path,
    seed: int,
    reset_state: bool = False,
) -> tuple[set[Path], dict]:
    """Select a subset that avoids images already selected in previous runs.

    The selected image ids are stored in state_file. When all images have been
    consumed, the state starts a new cycle and shuffles again. This turns the
    augmentation process from a fixed/static subset into a dynamic scheduler.
    """
    if reset_state and state_file.exists():
        state_file.unlink()

    if not image_paths or sample_count <= 0:
        return set(), {"cycle": 1, "used_before": 0, "used_after": 0, "remaining_after": 0}

    image_ids = [_relative_image_id(p, dataset_root) for p in image_paths]
    id_to_path = dict(zip(image_ids, image_paths))
    state = load_augment_state(state_file)

    # Remove stale ids if dataset changed.
    valid_ids = set(image_ids)
    used = set(x for x in state.get("used", []) if x in valid_ids)
    unused = [img_id for img_id in image_ids if img_id not in used]
    used_before = len(used)

    # If the remaining pool cannot satisfy this run, start a new cycle.
    if len(unused) < sample_count:
        state["cycle"] = int(state.get("cycle", 1)) + 1
        used = set()
        unused = image_ids.copy()
        used_before = 0

    rng = random.Random(seed + int(state.get("cycle", 1)))
    selected_ids = rng.sample(unused, min(sample_count, len(unused)))
    used.update(selected_ids)

    state["used"] = sorted(used)
    state["last_selected"] = selected_ids
    state["last_selected_count"] = len(selected_ids)
    state["last_sample_ratio"] = len(selected_ids) / max(1, len(image_ids))
    state["total_images"] = len(image_ids)
    save_augment_state(state, state_file)

    stats = {
        "cycle": int(state.get("cycle", 1)),
        "used_before": used_before,
        "used_after": len(used),
        "remaining_after": max(0, len(image_ids) - len(used)),
        "state_file": str(state_file),
    }
    return {id_to_path[img_id] for img_id in selected_ids}, stats


def copy_non_train_split(src_root: Path, dst_root: Path, split: str) -> None:
    src_img = src_root / "images" / split
    src_lbl = src_root / "labels" / split
    dst_img = dst_root / "images" / split
    dst_lbl = dst_root / "labels" / split
    dst_img.mkdir(parents=True, exist_ok=True)
    dst_lbl.mkdir(parents=True, exist_ok=True)

    for img_path in collect_images(src_img):
        shutil.copy2(img_path, dst_img / img_path.name)
        label_path = src_lbl / f"{img_path.stem}.txt"
        if label_path.exists():
            shutil.copy2(label_path, dst_lbl / label_path.name)


def apply_fog(img: np.ndarray) -> np.ndarray:
    h, w = img.shape[:2]
    fog = np.full_like(img, 255)
    alpha = np.random.uniform(0.15, 0.35)
    blurred = cv2.GaussianBlur(img, (0, 0), sigmaX=max(w, h) / 18.0)
    return cv2.addWeighted(blurred, 1.0 - alpha, fog, alpha, 0)


def apply_low_light(img: np.ndarray) -> np.ndarray:
    gamma = np.random.uniform(1.5, 2.4)
    table = np.array([((i / 255.0) ** gamma) * 255 for i in np.arange(256)], dtype=np.uint8)
    darker = cv2.LUT(img, table)
    return cv2.convertScaleAbs(darker, alpha=np.random.uniform(0.8, 0.95), beta=-np.random.randint(5, 25))


def apply_motion_blur(img: np.ndarray) -> np.ndarray:
    k = random.choice([3, 5, 7])
    kernel = np.zeros((k, k), dtype=np.float32)
    if random.random() < 0.5:
        kernel[k // 2, :] = 1.0
    else:
        kernel[:, k // 2] = 1.0
    kernel /= kernel.sum()
    return cv2.filter2D(img, -1, kernel)


def apply_noise_or_rain(img: np.ndarray) -> np.ndarray:
    out = img.astype(np.float32)
    if random.random() < 0.5:
        noise = np.random.normal(0, np.random.uniform(4, 12), img.shape).astype(np.float32)
        out += noise
    else:
        streaks = np.zeros_like(out)
        h, w = img.shape[:2]
        for _ in range(np.random.randint(150, 320)):
            x = np.random.randint(0, w)
            y = np.random.randint(0, h)
            length = np.random.randint(6, 14)
            cv2.line(streaks, (x, y), (min(w - 1, x + 1), min(h - 1, y + length)), (180, 180, 180), 1)
        out = cv2.addWeighted(out, 1.0, streaks, 0.15, 0)
    return np.clip(out, 0, 255).astype(np.uint8)


def apply_jpeg_compression(img: np.ndarray) -> np.ndarray:
    quality = int(np.random.uniform(35, 70))
    ok, enc = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    if not ok:
        return img
    dec = cv2.imdecode(enc, cv2.IMREAD_COLOR)
    return dec if dec is not None else img


def compose_weather(img: np.ndarray) -> np.ndarray:
    ops = [apply_fog, apply_low_light, apply_motion_blur, apply_noise_or_rain, apply_jpeg_compression]
    random.shuffle(ops)
    out = img.copy()
    for op in ops[: random.randint(2, 4)]:
        out = op(out)
    return out


def clip_box_xyxy(x1: int, y1: int, x2: int, y2: int, w: int, h: int) -> tuple[int, int, int, int] | None:
    x1 = max(0, min(w - 1, x1))
    y1 = max(0, min(h - 1, y1))
    x2 = max(0, min(w - 1, x2))
    y2 = max(0, min(h - 1, y2))
    if x2 - x1 < 4 or y2 - y1 < 4:
        return None
    return x1, y1, x2, y2


def overlap_ratio(candidate: tuple[int, int, int, int], existing: tuple[int, int, int, int]) -> float:
    ax1, ay1, ax2, ay2 = candidate
    bx1, by1, bx2, by2 = existing
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw = max(0, ix2 - ix1)
    ih = max(0, iy2 - iy1)
    inter = iw * ih
    area = max(1, (ax2 - ax1) * (ay2 - ay1))
    return inter / area


def small_sign_copy_paste(
    img: np.ndarray,
    boxes: list[YoloBox],
    small_threshold: float,
    max_paste: int,
) -> tuple[np.ndarray, list[YoloBox]]:
    h, w = img.shape[:2]
    out = img.copy()
    new_boxes = list(boxes)
    small_boxes = [b for b in boxes if b.area_norm() <= small_threshold]
    if not small_boxes:
        return out, new_boxes

    existing_xyxy = []
    for box in new_boxes:
        clipped = clip_box_xyxy(*box.to_xyxy(w, h), w, h)
        if clipped:
            existing_xyxy.append(clipped)

    paste_count = random.randint(1, max_paste)
    for _ in range(paste_count):
        src_box = random.choice(small_boxes)
        clipped = clip_box_xyxy(*src_box.to_xyxy(w, h), w, h)
        if clipped is None:
            continue
        x1, y1, x2, y2 = clipped
        crop = img[y1:y2, x1:x2].copy()
        if crop.size == 0:
            continue

        scale = np.random.uniform(0.55, 0.90)
        new_w = max(6, int(crop.shape[1] * scale))
        new_h = max(6, int(crop.shape[0] * scale))
        crop = cv2.resize(crop, (new_w, new_h), interpolation=cv2.INTER_AREA)

        for _ in range(25):
            px1 = random.randint(0, max(0, w - new_w - 1))
            py1 = random.randint(0, max(0, h - new_h - 1))
            px2, py2 = px1 + new_w, py1 + new_h
            candidate = (px1, py1, px2, py2)
            if any(overlap_ratio(candidate, ex) > 0.25 for ex in existing_xyxy):
                continue

            alpha = np.random.uniform(0.85, 1.0)
            roi = out[py1:py2, px1:px2].astype(np.float32)
            crop_f = crop.astype(np.float32)
            blended = cv2.addWeighted(roi, 1.0 - alpha, crop_f, alpha, 0)
            out[py1:py2, px1:px2] = blended.astype(np.uint8)

            xc = ((px1 + px2) / 2.0) / w
            yc = ((py1 + py2) / 2.0) / h
            bw = (px2 - px1) / w
            bh = (py2 - py1) / h
            new_boxes.append(YoloBox(src_box.cls_id, xc, yc, bw, bh))
            existing_xyxy.append(candidate)
            break

    return out, new_boxes


def process_train_split(
    src_root: Path,
    dst_root: Path,
    weather_ratio: float,
    small_sign_ratio: float,
    small_threshold: float,
    max_paste: int,
    augment_mode: str,
    sampling_mode: str,
    state_file: Path,
    seed: int,
    reset_state: bool,
) -> dict:
    src_images = src_root / "images" / "train"
    src_labels = src_root / "labels" / "train"
    dst_images = dst_root / "images" / "train"
    dst_labels = dst_root / "labels" / "train"

    dst_images.mkdir(parents=True, exist_ok=True)
    dst_labels.mkdir(parents=True, exist_ok=True)

    image_paths = collect_images(src_images)
    sample_count = max(1, int(round(len(image_paths) * weather_ratio))) if image_paths else 0

    if sampling_mode == "dynamic":
        selected, sampling_stats = dynamic_sample_without_replacement(
            image_paths=image_paths,
            sample_count=sample_count,
            dataset_root=src_root,
            state_file=state_file,
            seed=seed,
            reset_state=reset_state,
        )
    else:
        selected = set(random.sample(image_paths, sample_count)) if sample_count else set()
        sampling_stats = {
            "cycle": None,
            "used_before": None,
            "used_after": None,
            "remaining_after": None,
            "state_file": None,
        }

    stats = {
        "train_images": len(image_paths),
        "selected_for_weather": len(selected),
        "augment_mode": augment_mode,
        "sampling_mode": sampling_mode,
        **sampling_stats,
    }

    for img_path in tqdm(image_paths, desc="Process train", total=len(image_paths)):
        label_path = src_labels / f"{img_path.stem}.txt"
        img = cv2.imread(str(img_path))
        if img is None:
            continue
        boxes = load_labels(label_path)

        if augment_mode == "append" or img_path not in selected:
            shutil.copy2(img_path, dst_images / img_path.name)
            if label_path.exists():
                shutil.copy2(label_path, dst_labels / label_path.name)

        if img_path in selected:
            aug_img = compose_weather(img)
            aug_boxes = list(boxes)
            if random.random() < small_sign_ratio:
                aug_img, aug_boxes = small_sign_copy_paste(
                    aug_img,
                    aug_boxes,
                    small_threshold=small_threshold,
                    max_paste=max_paste,
                )
            if augment_mode == "append":
                out_img_name = f"{img_path.stem}_aug{img_path.suffix.lower()}"
                out_lbl_name = f"{img_path.stem}_aug.txt"
            else:
                out_img_name = img_path.name
                out_lbl_name = f"{img_path.stem}.txt"

            cv2.imwrite(str(dst_images / out_img_name), aug_img)
            save_labels(dst_labels / out_lbl_name, aug_boxes)

    return stats


def write_augmented_yaml(
    src_root: Path,
    dst_root: Path,
    augment_mode: str,
    weather_ratio: float,
    sampling_mode: str,
    state_file: Path,
) -> None:
    src_yaml = src_root / "data.yaml"
    if not src_yaml.exists():
        return
    data = load_yaml(src_yaml)
    data["path"] = str(dst_root.resolve()).replace("\\", "/")
    data["train"] = "images/train"
    data["val"] = "images/val"
    data["test"] = "images/test"
    data["augment_mode"] = augment_mode
    data["weather_ratio"] = float(weather_ratio)
    data["sampling_mode"] = sampling_mode
    data["state_file"] = str(state_file)
    data["augment_note"] = (
        "This dataset was generated by augment_weather_smallsign.py. "
        "append keeps originals and adds *_aug samples; replace swaps the selected weather_ratio of train images. "
        "dynamic sampling stores used train images in state_file and selects a different subset on later runs."
    )
    save_yaml(data, dst_root / "data_aug.yaml")


def main() -> None:
    args = parse_args()
    src_root = Path(args.src)
    dst_root = Path(args.dst)
    if not src_root.exists():
        raise FileNotFoundError(f"Source dataset not found: {src_root}")

    set_seed(args.seed)
    ensure_clean_dir(dst_root, args.overwrite)

    for split in ("val", "test"):
        copy_non_train_split(src_root, dst_root, split)

    stats = process_train_split(
        src_root=src_root,
        dst_root=dst_root,
        weather_ratio=args.weather_ratio,
        small_sign_ratio=args.small_sign_ratio,
        small_threshold=args.small_threshold,
        max_paste=args.max_paste,
        augment_mode=args.augment_mode,
        sampling_mode=args.sampling_mode,
        state_file=Path(args.state_file),
        seed=args.seed,
        reset_state=args.reset_state,
    )
    write_augmented_yaml(src_root, dst_root, args.augment_mode, args.weather_ratio, args.sampling_mode, Path(args.state_file))
    print(f"Augmented dataset created at: {dst_root.resolve()}")
    print(
        f"Mode={stats['augment_mode']} | sampling={stats['sampling_mode']} | "
        f"train_images={stats['train_images']} | selected_for_weather={stats['selected_for_weather']}"
    )
    if stats["sampling_mode"] == "dynamic":
        print(
            f"Dynamic cycle={stats['cycle']} | used_before={stats['used_before']} | "
            f"used_after={stats['used_after']} | remaining_after={stats['remaining_after']} | "
            f"state_file={stats['state_file']}"
        )


if __name__ == "__main__":
    main()
