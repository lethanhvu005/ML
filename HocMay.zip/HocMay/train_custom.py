from __future__ import annotations

import argparse
from pathlib import Path

import yaml
from ultralytics import YOLO


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train custom YOLOv8n traffic sign detector.")
    parser.add_argument("--model", type=str, default="yolov8n_bot_wiou_lska_odconv.yaml", help="Custom model YAML.")
    parser.add_argument(
        "--data",
        type=str,
        default="datasets/traffic_sign_aug/data_aug.yaml",
        help="Dataset YAML. This should point to the augmented dataset by default.",
    )
    parser.add_argument("--epochs", type=int, default=150)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--lr0", type=float, default=0.003)
    parser.add_argument("--momentum", type=float, default=0.937)
    parser.add_argument("--weight-decay", type=float, default=0.0005)
    parser.add_argument("--close-mosaic", type=int, default=10)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--device", type=str, default="0", help='Use "cpu" on local machine without CUDA.')
    parser.add_argument("--project", type=str, default="runs/custom_traffic_sign")
    parser.add_argument("--name", type=str, default="yolov8n_bot_wiou_lska_odconv")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--patience", type=int, default=50)
    parser.add_argument("--cache", type=str, default="ram", choices=["ram", "disk", "False"])
    return parser.parse_args()


def load_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def validate_data_yaml(data_path: Path) -> dict:
    data_cfg = load_yaml(data_path)
    names = data_cfg.get("names")
    nc = data_cfg.get("nc")

    if nc is None:
        raise KeyError(f"`nc` is missing in dataset yaml: {data_path}")
    if names is None:
        raise KeyError(f"`names` is missing in dataset yaml: {data_path}")

    if isinstance(names, dict):
        names_count = len(names)
    elif isinstance(names, list):
        names_count = len(names)
    else:
        raise TypeError(f"`names` must be a list or dict in: {data_path}")

    if int(nc) != names_count:
        raise ValueError(
            f"Mismatch in {data_path}: nc={nc} but names has {names_count} entries. "
            "Fix dataset yaml before training."
        )
    return data_cfg


def main() -> None:
    args = parse_args()
    model_path = Path(args.model)
    data_path = Path(args.data)

    if not model_path.exists():
        raise FileNotFoundError(f"Model YAML not found: {model_path}")
    if not data_path.exists():
        raise FileNotFoundError(f"Data YAML not found: {data_path}")

    data_cfg = validate_data_yaml(data_path)
    model = YOLO(str(model_path))
    cache = False if args.cache == "False" else args.cache

    print(f"Using dataset yaml: {data_path.resolve()}")
    print(f"Detected class count from data yaml: {data_cfg['nc']}")
    print("Note: model yaml nc is treated as a placeholder and will be overridden by data yaml during training.")

    model.train(
        data=str(data_path),
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        lr0=args.lr0,
        momentum=args.momentum,
        weight_decay=args.weight_decay,
        close_mosaic=args.close_mosaic,
        pretrained=False,
        workers=args.workers,
        device=args.device,
        project=args.project,
        name=args.name,
        seed=args.seed,
        patience=args.patience,
        cache=cache,
        optimizer="SGD",
        cos_lr=True,
        val=True,
        amp=True,
        hsv_h=0.010,
        hsv_s=0.45,
        hsv_v=0.25,
        degrees=0.0,
        translate=0.08,
        scale=0.35,
        shear=0.0,
        perspective=0.0,
        flipud=0.0,
        fliplr=0.5,
        mosaic=1.0,
        mixup=0.10,
        copy_paste=0.0,
        save=True,
        save_period=10,
        exist_ok=True,
    )


if __name__ == "__main__":
    main()
