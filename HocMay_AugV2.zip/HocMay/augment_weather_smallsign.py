from __future__ import annotations

import argparse
import json
import math
import random
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import cv2
import numpy as np
import yaml
from tqdm import tqdm


IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


@dataclass
class YoloBox:
    cls_id: int
    xc: float
    yc: float
    w: float
    h: float

    def to_line(self) -> str:
        return f"{self.cls_id} {self.xc:.6f} {self.yc:.6f} {self.w:.6f} {self.h:.6f}"

    def area_norm(self) -> float:
        return self.w * self.h

    def to_xyxy(self, img_w: int, img_h: int) -> tuple[int, int, int, int]:
        x1 = int((self.xc - self.w / 2.0) * img_w)
        y1 = int((self.yc - self.h / 2.0) * img_h)
        x2 = int((self.xc + self.w / 2.0) * img_w)
        y2 = int((self.yc + self.h / 2.0) * img_h)
        return x1, y1, x2, y2


@dataclass
class ObjectCrop:
    cls_id: int
    crop: np.ndarray
    src_name: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create dynamic, non-repeating YOLO augmentation dataset.")
    parser.add_argument("--src", type=str, default="datasets/traffic_sign", help="Source dataset root.")
    parser.add_argument("--dst", type=str, default="datasets/traffic_sign_aug", help="Output dataset root.")
    parser.add_argument("--weather-ratio", type=float, default=0.35, help="Fraction of train images selected for augmentation per run.")
    parser.add_argument("--small-sign-ratio", type=float, default=0.90, help="Probability of applying copy-paste to each selected image.")
    parser.add_argument("--small-threshold", type=float, default=0.04, help="Normalized bbox area threshold for small signs. Raise it if copy-paste is rare.")
    parser.add_argument("--max-paste", type=int, default=5, help="Maximum pasted signs per selected image.")
    parser.add_argument("--min-crop-size", type=int, default=8, help="Minimum crop side size used for copy-paste object bank.")
    parser.add_argument("--force-copy-paste", action="store_true", help="Always try copy-paste on selected images when object bank is available.")
    parser.add_argument("--save-preview", type=int, default=16, help="Number of augmented preview images with boxes to save in preview_aug. 0 disables.")
    parser.add_argument(
        "--augment-mode",
        type=str,
        default="append",
        choices=["append", "replace"],
        help="append: keep originals and add *_aug samples; replace: selected samples are overwritten by augmented versions.",
    )
    parser.add_argument(
        "--sampling-mode",
        type=str,
        default="dynamic",
        choices=["dynamic", "static"],
        help="dynamic: use --state-file to choose a different subset across runs; static: ordinary random sampling.",
    )
    parser.add_argument("--state-file", type=str, default="augment_state.json", help="JSON state file for dynamic non-repeating sampling.")
    parser.add_argument("--reset-state", action="store_true", help="Delete state file before sampling.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")
    parser.add_argument("--overwrite", action="store_true", help="Delete destination directory before writing.")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)


def load_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def save_yaml(data: dict, path: Path) -> None:
    with path.open("w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, sort_keys=False, allow_unicode=True)


def load_labels(label_path: Path) -> list[YoloBox]:
    if not label_path.exists():
        return []
    boxes: list[YoloBox] = []
    for line in label_path.read_text(encoding="utf-8").splitlines():
        parts = line.strip().split()
        if len(parts) != 5:
            continue
        cls_id, xc, yc, w, h = parts
        boxes.append(YoloBox(int(float(cls_id)), float(xc), float(yc), float(w), float(h)))
    return boxes


def save_labels(label_path: Path, boxes: Iterable[YoloBox]) -> None:
    label_path.parent.mkdir(parents=True, exist_ok=True)
    label_path.write_text("\n".join(box.to_line() for box in boxes), encoding="utf-8")


def ensure_clean_dir(dst: Path, overwrite: bool) -> None:
    if dst.exists() and overwrite:
        shutil.rmtree(dst)
    dst.mkdir(parents=True, exist_ok=True)


def collect_images(images_dir: Path) -> list[Path]:
    if not images_dir.exists():
        return []
    return sorted([p for p in images_dir.iterdir() if p.suffix.lower() in IMG_EXTS and p.is_file()])


def detect_layout(root: Path) -> str:
    """Return 'roboflow' for train/images layout or 'classic' for images/train layout."""
    if (root / "train" / "images").exists():
        return "roboflow"
    if (root / "images" / "train").exists():
        return "classic"
    # fallback: Roboflow exports usually have train/valid/test
    return "roboflow"


def split_aliases(split: str) -> list[str]:
    if split in {"val", "valid"}:
        return ["valid", "val"]
    return [split]


def get_dirs(root: Path, split: str, layout: str) -> tuple[Path, Path, str]:
    for s in split_aliases(split):
        if layout == "roboflow":
            img_dir = root / s / "images"
            lbl_dir = root / s / "labels"
        else:
            img_dir = root / "images" / s
            lbl_dir = root / "labels" / s
        if img_dir.exists() or lbl_dir.exists():
            return img_dir, lbl_dir, s
    s = split_aliases(split)[0]
    if layout == "roboflow":
        return root / s / "images", root / s / "labels", s
    return root / "images" / s, root / "labels" / s, s


def make_dirs(root: Path, split: str, layout: str) -> tuple[Path, Path]:
    if layout == "roboflow":
        img_dir = root / split / "images"
        lbl_dir = root / split / "labels"
    else:
        img_dir = root / "images" / split
        lbl_dir = root / "labels" / split
    img_dir.mkdir(parents=True, exist_ok=True)
    lbl_dir.mkdir(parents=True, exist_ok=True)
    return img_dir, lbl_dir


def _relative_image_id(img_path: Path, dataset_root: Path) -> str:
    try:
        return img_path.relative_to(dataset_root).as_posix()
    except ValueError:
        return img_path.name


def load_augment_state(state_file: Path) -> dict:
    if not state_file.exists():
        return {"cycle": 1, "used": []}
    try:
        with state_file.open("r", encoding="utf-8") as f:
            state = json.load(f)
    except Exception:
        state = {"cycle": 1, "used": []}
    if not isinstance(state, dict):
        state = {"cycle": 1, "used": []}
    state.setdefault("cycle", 1)
    state.setdefault("used", [])
    return state


def save_augment_state(state: dict, state_file: Path) -> None:
    state_file.parent.mkdir(parents=True, exist_ok=True)
    with state_file.open("w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def dynamic_sample_without_replacement(
    image_paths: list[Path],
    sample_count: int,
    dataset_root: Path,
    state_file: Path,
    seed: int,
    reset_state: bool = False,
) -> tuple[set[Path], dict]:
    if reset_state and state_file.exists():
        state_file.unlink()
    if not image_paths or sample_count <= 0:
        return set(), {"cycle": 1, "used_before": 0, "used_after": 0, "remaining_after_run": 0}

    image_ids = [_relative_image_id(p, dataset_root) for p in image_paths]
    id_to_path = dict(zip(image_ids, image_paths))
    state = load_augment_state(state_file)
    valid_ids = set(image_ids)
    used = set(x for x in state.get("used", []) if x in valid_ids)
    unused = [img_id for img_id in image_ids if img_id not in used]
    used_before = len(used)

    if len(unused) < sample_count:
        state["cycle"] = int(state.get("cycle", 1)) + 1
        used = set()
        unused = image_ids.copy()
        used_before = 0

    rng = random.Random(seed + int(state.get("cycle", 1)))
    selected_ids = rng.sample(unused, min(sample_count, len(unused)))
    used.update(selected_ids)

    state["used"] = sorted(used)
    state["last_selected"] = selected_ids
    state["last_selected_count"] = len(selected_ids)
    state["last_sample_ratio"] = len(selected_ids) / max(1, len(image_ids))
    state["total_images"] = len(image_ids)
    state["remaining_after_run"] = max(0, len(image_ids) - len(used))
    save_augment_state(state, state_file)

    stats = {
        "cycle": int(state.get("cycle", 1)),
        "used_before": used_before,
        "used_after": len(used),
        "remaining_after_run": max(0, len(image_ids) - len(used)),
        "state_file": str(state_file),
    }
    return {id_to_path[img_id] for img_id in selected_ids}, stats


def clip_box_xyxy(x1: int, y1: int, x2: int, y2: int, w: int, h: int) -> tuple[int, int, int, int] | None:
    x1 = max(0, min(w - 1, x1))
    y1 = max(0, min(h - 1, y1))
    x2 = max(0, min(w - 1, x2))
    y2 = max(0, min(h - 1, y2))
    if x2 - x1 < 4 or y2 - y1 < 4:
        return None
    return x1, y1, x2, y2


def overlap_ratio(candidate: tuple[int, int, int, int], existing: tuple[int, int, int, int]) -> float:
    ax1, ay1, ax2, ay2 = candidate
    bx1, by1, bx2, by2 = existing
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0, ix2 - ix1), max(0, iy2 - iy1)
    inter = iw * ih
    area = max(1, (ax2 - ax1) * (ay2 - ay1))
    return inter / area


def copy_non_train_split(src_root: Path, dst_root: Path, split: str, src_layout: str, dst_layout: str) -> None:
    src_img, src_lbl, actual_split = get_dirs(src_root, split, src_layout)
    dst_split = "valid" if actual_split == "valid" and dst_layout == "roboflow" else actual_split
    dst_img, dst_lbl = make_dirs(dst_root, dst_split, dst_layout)
    for img_path in collect_images(src_img):
        shutil.copy2(img_path, dst_img / img_path.name)
        label_path = src_lbl / f"{img_path.stem}.txt"
        if label_path.exists():
            shutil.copy2(label_path, dst_lbl / label_path.name)


# =========================
# Image-level augmentations
# =========================

def apply_fog(img: np.ndarray) -> np.ndarray:
    h, w = img.shape[:2]
    fog = np.full_like(img, 245)
    alpha = np.random.uniform(0.08, 0.22)
    # old sigma was too destructive. This keeps the sign still visible.
    blurred = cv2.GaussianBlur(img, (0, 0), sigmaX=max(w, h) / 55.0)
    return cv2.addWeighted(blurred, 1.0 - alpha, fog, alpha, 0)


def apply_low_light(img: np.ndarray) -> np.ndarray:
    gamma = np.random.uniform(1.15, 1.75)
    table = np.array([((i / 255.0) ** gamma) * 255 for i in np.arange(256)], dtype=np.uint8)
    darker = cv2.LUT(img, table)
    return cv2.convertScaleAbs(darker, alpha=np.random.uniform(0.88, 1.02), beta=-np.random.randint(0, 14))


def apply_motion_blur(img: np.ndarray) -> np.ndarray:
    k = random.choice([3, 5])
    kernel = np.zeros((k, k), dtype=np.float32)
    if random.random() < 0.5:
        kernel[k // 2, :] = 1.0
    else:
        kernel[:, k // 2] = 1.0
    kernel /= kernel.sum()
    return cv2.filter2D(img, -1, kernel)


def apply_noise_or_rain(img: np.ndarray) -> np.ndarray:
    out = img.astype(np.float32)
    if random.random() < 0.45:
        noise = np.random.normal(0, np.random.uniform(2.0, 7.0), img.shape).astype(np.float32)
        out += noise
    else:
        streaks = np.zeros_like(out)
        h, w = img.shape[:2]
        for _ in range(np.random.randint(45, 130)):
            x, y = np.random.randint(0, w), np.random.randint(0, h)
            length = np.random.randint(5, 12)
            cv2.line(streaks, (x, y), (min(w - 1, x + 1), min(h - 1, y + length)), (185, 185, 185), 1)
        out = cv2.addWeighted(out, 1.0, streaks, np.random.uniform(0.08, 0.16), 0)
    return np.clip(out, 0, 255).astype(np.uint8)


def apply_jpeg_compression(img: np.ndarray) -> np.ndarray:
    quality = int(np.random.uniform(55, 88))
    ok, enc = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    if not ok:
        return img
    dec = cv2.imdecode(enc, cv2.IMREAD_COLOR)
    return dec if dec is not None else img


# NEW AUGMENT 1: HSV/color jitter for camera/color temperature changes.
def apply_hsv_jitter(img: np.ndarray) -> np.ndarray:
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[..., 0] = (hsv[..., 0] + np.random.uniform(-6, 6)) % 180
    hsv[..., 1] *= np.random.uniform(0.75, 1.25)
    hsv[..., 2] *= np.random.uniform(0.82, 1.18)
    hsv[..., 1:] = np.clip(hsv[..., 1:], 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)


# NEW AUGMENT 2: CLAHE/contrast enhancement for backlight and low contrast scenes.
def apply_clahe_contrast(img: np.ndarray) -> np.ndarray:
    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=float(np.random.uniform(1.2, 2.4)), tileGridSize=(8, 8))
    l2 = clahe.apply(l)
    out = cv2.merge((l2, a, b))
    out = cv2.cvtColor(out, cv2.COLOR_LAB2BGR)
    return cv2.convertScaleAbs(out, alpha=np.random.uniform(0.92, 1.08), beta=np.random.randint(-5, 6))


# NEW AUGMENT 3: shadow/glare for sunlight, trees, vehicle reflections.
def apply_shadow_glare(img: np.ndarray) -> np.ndarray:
    h, w = img.shape[:2]
    out = img.astype(np.float32)
    yy, xx = np.mgrid[0:h, 0:w]
    if random.random() < 0.55:
        # soft shadow polygon
        pts = np.array([
            [np.random.randint(0, w), 0],
            [np.random.randint(0, w), 0],
            [np.random.randint(0, w), h],
            [np.random.randint(0, w), h],
        ], dtype=np.int32)
        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.fillPoly(mask, [pts], 255)
        mask = cv2.GaussianBlur(mask, (0, 0), sigmaX=max(h, w) / 18.0).astype(np.float32) / 255.0
        strength = np.random.uniform(0.15, 0.35)
        out *= (1.0 - strength * mask[..., None])
    else:
        # mild sun glare spot
        cx, cy = np.random.randint(0, w), np.random.randint(0, h)
        radius = np.random.uniform(0.12, 0.28) * max(h, w)
        dist = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
        mask = np.clip(1.0 - dist / radius, 0, 1) ** 2
        strength = np.random.uniform(25, 60)
        out += strength * mask[..., None]
    return np.clip(out, 0, 255).astype(np.uint8)


def compose_weather(img: np.ndarray) -> tuple[np.ndarray, list[str]]:
    ops = [
        ("fog", apply_fog),
        ("lowlight", apply_low_light),
        ("motionblur", apply_motion_blur),
        ("rain_noise", apply_noise_or_rain),
        ("jpeg", apply_jpeg_compression),
        ("hsv", apply_hsv_jitter),
        ("clahe", apply_clahe_contrast),
        ("shadow_glare", apply_shadow_glare),
    ]
    random.shuffle(ops)
    # Apply 2-3 mild transforms instead of 4 harsh transforms to avoid destroying images.
    n_ops = random.choice([2, 2, 3])
    out = img.copy()
    names: list[str] = []
    for name, op in ops[:n_ops]:
        out = op(out)
        names.append(name)
    return out, names


def build_object_bank(
    image_paths: list[Path],
    labels_dir: Path,
    small_threshold: float,
    min_crop_size: int,
) -> list[ObjectCrop]:
    bank: list[ObjectCrop] = []
    fallback: list[ObjectCrop] = []
    loose_threshold = max(small_threshold * 2.5, small_threshold + 0.03)
    for img_path in tqdm(image_paths, desc="Build copy-paste object bank", total=len(image_paths)):
        label_path = labels_dir / f"{img_path.stem}.txt"
        boxes = load_labels(label_path)
        if not boxes:
            continue
        img = cv2.imread(str(img_path))
        if img is None:
            continue
        h, w = img.shape[:2]
        for box in boxes:
            clipped = clip_box_xyxy(*box.to_xyxy(w, h), w, h)
            if clipped is None:
                continue
            x1, y1, x2, y2 = clipped
            if min(x2 - x1, y2 - y1) < min_crop_size:
                continue
            crop = img[y1:y2, x1:x2].copy()
            item = ObjectCrop(box.cls_id, crop, img_path.name)
            if box.area_norm() <= loose_threshold:
                bank.append(item)
            fallback.append(item)
    # If the dataset labels do not have many boxes below the threshold, still use all available objects.
    return bank if bank else fallback


def make_soft_mask(h: int, w: int) -> np.ndarray:
    mask = np.ones((h, w), dtype=np.float32)
    border = max(2, min(h, w) // 7)
    if border > 1:
        mask[:border, :] *= np.linspace(0.35, 1.0, border)[:, None]
        mask[-border:, :] *= np.linspace(1.0, 0.35, border)[:, None]
        mask[:, :border] *= np.linspace(0.35, 1.0, border)[None, :]
        mask[:, -border:] *= np.linspace(1.0, 0.35, border)[None, :]
    return mask[..., None]


def small_sign_copy_paste(
    img: np.ndarray,
    boxes: list[YoloBox],
    object_bank: list[ObjectCrop],
    max_paste: int,
) -> tuple[np.ndarray, list[YoloBox], int]:
    h, w = img.shape[:2]
    if not object_bank:
        return img.copy(), list(boxes), 0

    out = img.copy()
    new_boxes = list(boxes)
    existing_xyxy = []
    for box in new_boxes:
        clipped = clip_box_xyxy(*box.to_xyxy(w, h), w, h)
        if clipped:
            existing_xyxy.append(clipped)

    target_paste = random.randint(1, max(1, max_paste))
    pasted = 0
    for _ in range(target_paste):
        item = random.choice(object_bank)
        crop = item.crop.copy()
        if crop.size == 0:
            continue

        # Copy-paste should produce SMALL signs, but not invisible ones.
        scale = np.random.uniform(0.45, 0.95)
        new_w = max(8, int(crop.shape[1] * scale))
        new_h = max(8, int(crop.shape[0] * scale))
        # Avoid huge pasted crops.
        max_side = int(min(h, w) * np.random.uniform(0.05, 0.16))
        if max(new_w, new_h) > max_side:
            ratio = max_side / max(new_w, new_h)
            new_w = max(8, int(new_w * ratio))
            new_h = max(8, int(new_h * ratio))
        if new_w >= w or new_h >= h:
            continue
        crop = cv2.resize(crop, (new_w, new_h), interpolation=cv2.INTER_AREA)

        # Mild color matching to current image brightness.
        crop = cv2.convertScaleAbs(crop, alpha=np.random.uniform(0.90, 1.08), beta=np.random.randint(-8, 9))
        mask = make_soft_mask(new_h, new_w)

        for _try in range(80):
            px1 = random.randint(0, max(0, w - new_w - 1))
            py1 = random.randint(0, max(0, h - new_h - 1))
            px2, py2 = px1 + new_w, py1 + new_h
            candidate = (px1, py1, px2, py2)
            if any(overlap_ratio(candidate, ex) > 0.15 for ex in existing_xyxy):
                continue
            roi = out[py1:py2, px1:px2].astype(np.float32)
            crop_f = crop.astype(np.float32)
            alpha = np.random.uniform(0.88, 1.0)
            blended = roi * (1 - alpha * mask) + crop_f * (alpha * mask)
            out[py1:py2, px1:px2] = np.clip(blended, 0, 255).astype(np.uint8)

            xc = ((px1 + px2) / 2.0) / w
            yc = ((py1 + py2) / 2.0) / h
            bw = (px2 - px1) / w
            bh = (py2 - py1) / h
            new_boxes.append(YoloBox(item.cls_id, xc, yc, bw, bh))
            existing_xyxy.append(candidate)
            pasted += 1
            break
    return out, new_boxes, pasted


def draw_preview(img: np.ndarray, boxes: list[YoloBox], out_path: Path) -> None:
    h, w = img.shape[:2]
    vis = img.copy()
    for box in boxes:
        clipped = clip_box_xyxy(*box.to_xyxy(w, h), w, h)
        if not clipped:
            continue
        x1, y1, x2, y2 = clipped
        cv2.rectangle(vis, (x1, y1), (x2, y2), (0, 0, 255), 2)
        cv2.putText(vis, str(box.cls_id), (x1, max(0, y1 - 3)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 1)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out_path), vis)


def process_train_split(
    src_root: Path,
    dst_root: Path,
    src_layout: str,
    dst_layout: str,
    weather_ratio: float,
    small_sign_ratio: float,
    small_threshold: float,
    max_paste: int,
    min_crop_size: int,
    force_copy_paste: bool,
    save_preview: int,
    augment_mode: str,
    sampling_mode: str,
    state_file: Path,
    seed: int,
    reset_state: bool,
) -> dict:
    src_images, src_labels, actual_train = get_dirs(src_root, "train", src_layout)
    dst_images, dst_labels = make_dirs(dst_root, actual_train, dst_layout)

    image_paths = collect_images(src_images)
    sample_count = max(1, int(round(len(image_paths) * weather_ratio))) if image_paths else 0

    if sampling_mode == "dynamic":
        selected, sampling_stats = dynamic_sample_without_replacement(image_paths, sample_count, src_root, state_file, seed, reset_state)
    else:
        selected = set(random.sample(image_paths, sample_count)) if sample_count else set()
        sampling_stats = {"cycle": None, "used_before": None, "used_after": None, "remaining_after_run": None, "state_file": None}

    object_bank = build_object_bank(image_paths, src_labels, small_threshold, min_crop_size)

    stats = {
        "train_images": len(image_paths),
        "selected_for_augmentation": len(selected),
        "augment_mode": augment_mode,
        "sampling_mode": sampling_mode,
        "object_bank_size": len(object_bank),
        "copy_paste_images": 0,
        "copy_paste_objects": 0,
        "weather_ops": {},
        "new_augmented_images": 0,
        "preview_saved": 0,
        **sampling_stats,
    }

    preview_dir = dst_root / "preview_aug"

    for img_path in tqdm(image_paths, desc="Process train", total=len(image_paths)):
        label_path = src_labels / f"{img_path.stem}.txt"
        img = cv2.imread(str(img_path))
        if img is None:
            continue
        boxes = load_labels(label_path)

        if augment_mode == "append" or img_path not in selected:
            shutil.copy2(img_path, dst_images / img_path.name)
            if label_path.exists():
                shutil.copy2(label_path, dst_labels / label_path.name)
            else:
                save_labels(dst_labels / f"{img_path.stem}.txt", [])

        if img_path in selected:
            aug_img = img.copy()
            aug_boxes = list(boxes)

            do_cp = bool(object_bank) and (force_copy_paste or random.random() < small_sign_ratio)
            pasted = 0
            if do_cp:
                aug_img, aug_boxes, pasted = small_sign_copy_paste(aug_img, aug_boxes, object_bank, max_paste=max_paste)
                if pasted > 0:
                    stats["copy_paste_images"] += 1
                    stats["copy_paste_objects"] += pasted

            aug_img, op_names = compose_weather(aug_img)
            for name in op_names:
                stats["weather_ops"][name] = stats["weather_ops"].get(name, 0) + 1

            tag = "cp" if pasted > 0 else "aug"
            if augment_mode == "append":
                out_img_name = f"{img_path.stem}_{tag}{img_path.suffix.lower()}"
                out_lbl_name = f"{img_path.stem}_{tag}.txt"
            else:
                out_img_name = img_path.name
                out_lbl_name = f"{img_path.stem}.txt"

            cv2.imwrite(str(dst_images / out_img_name), aug_img)
            save_labels(dst_labels / out_lbl_name, aug_boxes)
            stats["new_augmented_images"] += 1

            if save_preview > 0 and stats["preview_saved"] < save_preview:
                draw_preview(aug_img, aug_boxes, preview_dir / f"preview_{out_img_name}")
                stats["preview_saved"] += 1

    return stats


def write_augmented_yaml(
    src_root: Path,
    dst_root: Path,
    dst_layout: str,
    augment_mode: str,
    weather_ratio: float,
    small_sign_ratio: float,
    sampling_mode: str,
    state_file: Path,
) -> None:
    src_yaml = src_root / "data.yaml"
    data = load_yaml(src_yaml) if src_yaml.exists() else {}
    data["path"] = str(dst_root.resolve()).replace("\\", "/")
    if dst_layout == "roboflow":
        data["train"] = "train/images"
        data["val"] = "valid/images" if (dst_root / "valid" / "images").exists() else "val/images"
        data["test"] = "test/images"
    else:
        data["train"] = "images/train"
        data["val"] = "images/val" if (dst_root / "images" / "val").exists() else "images/valid"
        data["test"] = "images/test"
    data["augment_mode"] = augment_mode
    data["weather_ratio"] = float(weather_ratio)
    data["small_sign_ratio"] = float(small_sign_ratio)
    data["sampling_mode"] = sampling_mode
    data["state_file"] = str(state_file)
    data["augment_note"] = (
        "Dynamic augmentation with non-repeating sampling. Includes mild fog, low-light, motion blur, rain/noise, JPEG, "
        "plus 3 added augmentations: HSV color jitter, CLAHE contrast, shadow/glare. Copy-paste uses a global object bank, "
        "not only objects from the current image, and writes statistics to augmentation_report.json."
    )
    save_yaml(data, dst_root / "data_aug.yaml")


def main() -> None:
    args = parse_args()
    src_root = Path(args.src)
    dst_root = Path(args.dst)
    if not src_root.exists():
        raise FileNotFoundError(f"Source dataset not found: {src_root}")

    set_seed(args.seed)
    ensure_clean_dir(dst_root, args.overwrite)

    src_layout = detect_layout(src_root)
    dst_layout = src_layout

    for split in ("valid", "val", "test"):
        src_img, _, actual = get_dirs(src_root, split, src_layout)
        if src_img.exists():
            copy_non_train_split(src_root, dst_root, actual, src_layout, dst_layout)

    stats = process_train_split(
        src_root=src_root,
        dst_root=dst_root,
        src_layout=src_layout,
        dst_layout=dst_layout,
        weather_ratio=args.weather_ratio,
        small_sign_ratio=args.small_sign_ratio,
        small_threshold=args.small_threshold,
        max_paste=args.max_paste,
        min_crop_size=args.min_crop_size,
        force_copy_paste=args.force_copy_paste,
        save_preview=args.save_preview,
        augment_mode=args.augment_mode,
        sampling_mode=args.sampling_mode,
        state_file=Path(args.state_file),
        seed=args.seed,
        reset_state=args.reset_state,
    )
    stats["src_layout"] = src_layout
    stats["dst_layout"] = dst_layout
    stats["dst"] = str(dst_root.resolve())
    stats["small_threshold"] = args.small_threshold
    stats["max_paste"] = args.max_paste
    stats["added_augmentations"] = ["hsv_color_jitter", "clahe_contrast", "shadow_glare"]

    write_augmented_yaml(
        src_root, dst_root, dst_layout, args.augment_mode, args.weather_ratio, args.small_sign_ratio, args.sampling_mode, Path(args.state_file)
    )
    report_path = dst_root / "augmentation_report.json"
    report_path.write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Augmented dataset created at: {dst_root.resolve()}")
    print(f"Layout={src_layout} | Mode={stats['augment_mode']} | sampling={stats['sampling_mode']}")
    print(f"train_images={stats['train_images']} | selected={stats['selected_for_augmentation']} | new_augmented={stats['new_augmented_images']}")
    print(f"object_bank_size={stats['object_bank_size']} | copy_paste_images={stats['copy_paste_images']} | copy_paste_objects={stats['copy_paste_objects']}")
    print(f"weather_ops={stats['weather_ops']}")
    print(f"report={report_path}")
    if stats["sampling_mode"] == "dynamic":
        print(
            f"Dynamic cycle={stats['cycle']} | used_before={stats['used_before']} | "
            f"used_after={stats['used_after']} | remaining_after_run={stats['remaining_after_run']} | "
            f"state_file={stats['state_file']}"
        )


if __name__ == "__main__":
    main()
