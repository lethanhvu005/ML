from __future__ import annotations

import torch
import torch.nn as nn

from ultralytics.nn.modules.conv import Conv


class MHSA2D(nn.Module):
    """
    Simple global multi-head self-attention for 2D feature maps.

    Practical approximation:
    - Global attention without relative position bias.
    - Used on the last backbone feature map where spatial size is small enough.
    """

    def __init__(self, channels: int, heads: int = 4) -> None:
        super().__init__()
        if channels % heads != 0:
            raise ValueError(f"channels={channels} must be divisible by heads={heads}")
        self.heads = heads
        self.head_dim = channels // heads
        self.scale = self.head_dim ** -0.5
        self.qkv = nn.Conv2d(channels, channels * 3, 1, bias=False)
        self.proj = nn.Conv2d(channels, channels, 1, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape
        qkv = self.qkv(x)
        q, k, v = qkv.chunk(3, dim=1)
        q = q.reshape(b, self.heads, self.head_dim, h * w).transpose(-2, -1)
        k = k.reshape(b, self.heads, self.head_dim, h * w)
        v = v.reshape(b, self.heads, self.head_dim, h * w).transpose(-2, -1)

        attn = (q @ k) * self.scale
        attn = attn.softmax(dim=-1)
        out = attn @ v
        out = out.transpose(-2, -1).reshape(b, c, h, w)
        return self.proj(out)


class BoTBlock(nn.Module):
    def __init__(self, channels: int, heads: int = 4, expansion: float = 2.0, shortcut: bool = True) -> None:
        super().__init__()
        hidden = int(channels * expansion)
        self.cv1 = Conv(channels, channels, 1, 1)
        self.attn = MHSA2D(channels, heads=heads)
        self.ffn = nn.Sequential(
            Conv(channels, hidden, 1, 1),
            Conv(hidden, channels, 1, 1, act=False),
        )
        self.norm1 = nn.BatchNorm2d(channels)
        self.norm2 = nn.BatchNorm2d(channels)
        self.act = nn.SiLU()
        self.shortcut = shortcut

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.cv1(x)
        y = self.act(self.norm1(self.attn(y)))
        if self.shortcut:
            y = x + y
        z = self.norm2(self.ffn(y))
        return y + z if self.shortcut else z


class BoTNet(nn.Module):
    """
    Stack of lightweight Bottleneck Transformer blocks.

    Expected usage: after SPPF where feature map is already low resolution.
    """

    def __init__(self, c1: int, c2: int | None = None, heads: int = 4, n: int = 1) -> None:
        super().__init__()
        c2 = c1 if c2 is None else c2
        self.cv = Conv(c1, c2, 1, 1) if c1 != c2 else nn.Identity()
        self.blocks = nn.Sequential(*[BoTBlock(c2, heads=heads) for _ in range(n)])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.blocks(self.cv(x))
