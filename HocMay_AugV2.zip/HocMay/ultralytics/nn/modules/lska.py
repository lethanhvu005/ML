from __future__ import annotations

import torch
import torch.nn as nn

from ultralytics.nn.modules.conv import Conv


class LSKA(nn.Module):
    """
    Large Separable Kernel Attention.

    This is a practical approximation tailored for YOLO feature maps:
    depthwise large-kernel attention + pointwise projection + residual gating.
    """

    def __init__(self, channels: int, kernel_size: int = 11) -> None:
        super().__init__()
        pad_small = 2
        pad_large = kernel_size // 2
        self.pre = nn.Conv2d(channels, channels, 5, 1, pad_small, groups=channels, bias=False)
        self.h = nn.Conv2d(channels, channels, (1, kernel_size), 1, (0, pad_large), groups=channels, bias=False)
        self.v = nn.Conv2d(channels, channels, (kernel_size, 1), 1, (pad_large, 0), groups=channels, bias=False)
        self.proj = nn.Conv2d(channels, channels, 1, 1, 0, bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        attn = self.pre(x)
        attn = self.h(attn)
        attn = self.v(attn)
        attn = self.sigmoid(self.proj(attn))
        return x * attn


class Bottleneck_LSKA(nn.Module):
    def __init__(self, c1: int, c2: int, shortcut: bool = True, g: int = 1, e: float = 0.5) -> None:
        super().__init__()
        hidden = int(c2 * e)
        self.cv1 = Conv(c1, hidden, 1, 1)
        self.cv2 = Conv(hidden, c2, 3, 1, g=g)
        self.attn = LSKA(c2)
        self.add = shortcut and c1 == c2

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.attn(self.cv2(self.cv1(x)))
        return x + y if self.add else y


class C2f_LSKA(nn.Module):
    """
    Drop-in replacement for C2f using Bottleneck_LSKA blocks.
    """

    def __init__(
        self,
        c1: int,
        c2: int,
        n: int = 1,
        shortcut: bool = False,
        g: int = 1,
        e: float = 0.5,
    ) -> None:
        super().__init__()
        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)
        self.m = nn.ModuleList(Bottleneck_LSKA(self.c, self.c, shortcut, g, e=1.0) for _ in range(n))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = list(self.cv1(x).chunk(2, 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))

    def forward_split(self, x: torch.Tensor) -> torch.Tensor:
        y = list(self.cv1(x).split((self.c, self.c), 1))
        y.extend(m(y[-1]) for m in self.m)
        return self.cv2(torch.cat(y, 1))
