from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


class ODConv2d(nn.Module):
    """
    Practical Omni-Dimensional Dynamic Convolution.

    Approximation notes:
    - Uses sample-wise kernel attention over K candidate kernels.
    - Keeps the design lightweight enough for Colab.
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        stride: int = 1,
        padding: int | None = None,
        dilation: int = 1,
        groups: int = 1,
        reduction: float = 0.25,
        kernel_num: int = 4,
        bias: bool = False,
    ) -> None:
        super().__init__()
        if padding is None:
            padding = kernel_size // 2
        hidden = max(16, int(in_channels * reduction))
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.dilation = dilation
        self.groups = groups
        self.kernel_num = kernel_num

        self.attn_pool = nn.AdaptiveAvgPool2d(1)
        self.attn_mlp = nn.Sequential(
            nn.Conv2d(in_channels, hidden, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, kernel_num, 1, bias=True),
        )
        self.weight = nn.Parameter(
            torch.randn(kernel_num, out_channels, in_channels // groups, kernel_size, kernel_size)
        )
        self.bias = nn.Parameter(torch.zeros(kernel_num, out_channels)) if bias else None
        self.reset_parameters()

    def reset_parameters(self) -> None:
        for k in range(self.kernel_num):
            nn.init.kaiming_uniform_(self.weight[k], a=math.sqrt(5))
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape
        attn = self.attn_mlp(self.attn_pool(x)).view(b, self.kernel_num)
        attn = torch.softmax(attn, dim=1)
        weight = torch.einsum("bk,kocij->bocij", attn, self.weight)
        bias = torch.einsum("bk,ko->bo", attn, self.bias).reshape(-1) if self.bias is not None else None

        x = x.reshape(1, b * c, h, w)
        weight = weight.reshape(
            b * self.out_channels,
            self.in_channels // self.groups,
            self.kernel_size,
            self.kernel_size,
        )
        y = F.conv2d(
            x,
            weight=weight,
            bias=bias,
            stride=self.stride,
            padding=self.padding,
            dilation=self.dilation,
            groups=b * self.groups,
        )
        return y.reshape(b, self.out_channels, y.shape[-2], y.shape[-1])


class ODConv(nn.Module):
    """
    Conv-like wrapper so the YAML can use ODConv similarly to Conv.
    """

    default_act = nn.SiLU()

    def __init__(
        self,
        c1: int,
        c2: int,
        k: int = 3,
        s: int = 1,
        p: int | None = None,
        g: int = 1,
        d: int = 1,
        act: bool | nn.Module = True,
        kernel_num: int = 4,
    ) -> None:
        super().__init__()
        self.conv = ODConv2d(c1, c2, kernel_size=k, stride=s, padding=p, groups=g, dilation=d, kernel_num=kernel_num)
        self.bn = nn.BatchNorm2d(c2)
        if act is True:
            self.act = self.default_act
        elif isinstance(act, nn.Module):
            self.act = act
        else:
            self.act = nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.act(self.bn(self.conv(x)))

    def forward_fuse(self, x: torch.Tensor) -> torch.Tensor:
        return self.act(self.conv(x))
